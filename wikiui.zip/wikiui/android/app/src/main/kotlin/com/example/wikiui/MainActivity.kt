package com.example.wikiui

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
