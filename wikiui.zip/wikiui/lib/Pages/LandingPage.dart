import 'dart:async';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
class landing extends StatefulWidget {
  @override
  _landingState createState() => _landingState();
}


class _landingState extends State<landing> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    startTimer();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromRGBO(212, 244, 255, 1.0),
      body: Center(
        child: Container(
            child:Image.asset('assets/bus.png',fit: BoxFit.fill,)
        ),
      ),
    );
  }

  void startTimer() {
    Timer(
        Duration(seconds: 2),
            () => Navigator.pushReplacementNamed(context, '/dashboard'));
  }
}
