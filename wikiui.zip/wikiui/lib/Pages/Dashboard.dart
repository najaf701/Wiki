import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_search_bar/flutter_search_bar.dart';
import 'package:http/http.dart' as http;
class dashboard extends StatefulWidget {
  @override
  _dashboardState createState() => _dashboardState();
}

class _dashboardState extends State<dashboard> {
  SearchBar searchBar;
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  final TextEditingController _searchQuery = new TextEditingController();
  List<String> _list;
  bool _IsSearching;
  String _searchText = "";

  _SearchListState() {
    _searchQuery.addListener(() {
      if (_searchQuery.text.isEmpty) {
        setState(() {
          _IsSearching = false;
          _searchText = "";
        });
      }
      else {
        setState(() {
          _IsSearching = true;
          _searchText = _searchQuery.text;
        });
      }
    });
  }

  @override
  void initState() {
    super.initState();
    _IsSearching = false;
    init();

  }
  void init() {
    _list = List();
    _list.add("Google");
    _list.add("IOS");
    _list.add("Andorid");
    _list.add("Dart");
    _list.add("Flutter");
    _list.add("Python");
    _list.add("React");
    _list.add("Xamarin");
    _list.add("Kotlin");
    _list.add("Java");
    _list.add("RxAndroid");
  }
  // List videoListholy = new List();
  // var urlrel='https://en.wikipedia.org//w/api.php?action=query&format=json&prop=pageimages%7Cpageterms&generator=prefixsearch&redirects=1&formatversion=2&piprop=thumbnail&pithumbsize=50&pilimit=10&wbptterms=description&gpssearch=Sachin+T&gpslimit=10';
  // Future<String> holy() async {
  //   var response = await http.post(urlrel, body:  {
  //   });
  //   var data = json.decode(response.body);
  //   print(data);
  //   setState(() {
  //     videoListholy= data['pages'];
  //   });
  //   print('hello');
  //   print(videoListholy[0]['pages']);
  // }

  void _handleSearchStart() {
    setState(() {
      _IsSearching = true;
    });
  }

  void _handleSearchEnd() {
    setState(() {
      this.actionIcon = new Icon(Icons.search, color: Colors.white,);
      this.appBarTitle =
      new Text("Search Sample", style: new TextStyle(color: Colors.white),);
      _IsSearching = false;
      _searchQuery.clear();
    });
  }

  // List<ChildItem> _buildList() {
  //   return _list.map((contact) => new ChildItem(contact)).toList();
  // }
  //
  // List<ChildItem> _buildSearchList() {
  //   if (_searchText.isEmpty) {
  //     return _list.map((contact) => new ChildItem(contact))
  //         .toList();
  //   }
  //   else {
  //     List<String> _searchList = List();
  //     for (int i = 0; i < _list.length; i++) {
  //       String  name = _list.elementAt(i);
  //       if (name.toLowerCase().contains(_searchText.toLowerCase())) {
  //         _searchList.add(name);
  //       }
  //     }
  //     return _searchList.map((contact) => new ChildItem(contact))
  //         .toList();
  //   }
  // }



  Widget appBarTitle = new Text("Search Sample", style: new TextStyle(color: Colors.white),);
  Icon actionIcon = new Icon(Icons.search, color: Colors.white,);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          centerTitle: true,
          title: appBarTitle,
          actions: <Widget>[
            new IconButton(icon: actionIcon, onPressed: () {
              setState(() {
                if (this.actionIcon.icon == Icons.search) {
                  this.actionIcon = new Icon(Icons.close, color: Colors.white,);
                  this.appBarTitle = new TextField(
                    controller: _searchQuery,
                    style: new TextStyle(
                      color: Colors.white,

                    ),
                    decoration: new InputDecoration(
                        prefixIcon: new Icon(Icons.search, color: Colors.white),
                        hintText: "Search...",
                        hintStyle: new TextStyle(color: Colors.white)
                    ),
                  );
                  _handleSearchStart();
                }
                else {
                  _handleSearchEnd();
                }
              });
            },),
          ]
      ),
      body: Column(
        children: [
          // Align(
          //   alignment: Alignment.topLeft,
          //   child: Container(
          //     height: 80,
          //     width: MediaQuery.of(context).size.width,
          //     // color:  Color.fromRGBO(0, 96, 143, 1.0),
          //     decoration: BoxDecoration(
          //         color:  Color.fromRGBO(0, 96, 143, 1.0),
          //         border: Border.all(
          //           color:  Color.fromRGBO(0, 96, 143, 1.0),// set border color
          //         ),   // set border width
          //         borderRadius: BorderRadius.all(
          //             Radius.circular(10.0)), // set rounded corner radius
          //         boxShadow: [BoxShadow(blurRadius: 8,color: Colors.black,offset: Offset(1,3))]// make rounded corner of border
          //     ),
          //
          //     child: Padding(
          //       padding: const EdgeInsets.fromLTRB(20, 35, 0, 0),
          //       child: Text('Vehicle Master',style: TextStyle(
          //           color: Colors.white,fontWeight: FontWeight.bold,fontSize: 25
          //
          //       ),),
          //     ),
          //   ),
          // ),
          Container(
            height: 500,
            decoration: BoxDecoration(
              image:DecorationImage(image:AssetImage('assets/backgrnd.png'),fit: BoxFit.fill),
            ),
            child: Expanded(
              child: ListView.builder(
                itemCount: 10,
                itemBuilder: (context, index) {
                  return Column(
                    children: <Widget>[
                      Container(
                        height: 100,
                        width: MediaQuery.of(context).size.width,
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(10, 2, 0, 0),
                          child: Card(
                            color: Colors.black12,
                            elevation: 0.0,
                            child: FittedBox(
                              child: Row(
                                children: <Widget>[
                                  Padding(
                                    padding: EdgeInsets.all(10.0),
                                    child: GestureDetector(
                                      onTap: () async{
                                        // setState(() async{
                                        //   currentVideoUrlm =  videoListspidua[index]['fileUpload'];
                                        //   title = videoListspidua[index]['title'];
                                        //   Description = videoListspidua[index]['description'];
                                        //   doc = videoListspidua[index]['type'];
                                        //   SharedPreferences prefs = await SharedPreferences.getInstance();
                                        //   prefs.setString('url', currentVideoUrlm);
                                        //   prefs.setString('title', title);
                                        //   prefs.setString('description', Description);
                                        //   getSave(videoListspidua[index]['id']);
                                        //   if (doc == 1) {
                                        //     Navigator.pushNamed(context, '/vlc');
                                        //     print('sucess');
                                        //   }else{
                                        //     // If that response was not OK, throw an error.
                                        //     Navigator.pushNamed(context, '/YoutubePlayerDemoApp');
                                        //     print('failed hqai');
                                        //   }
                                        //   //  Videoid = videoList[index]['userID'];
                                        //
                                        // });

                                      },
                                      child: FittedBox(
                                        child: Container(
                                          width: 230.0,
                                          height: 150.0,
                                          child: Image(image: AssetImage('assets/edulogo.png'),)
                                        ),
                                      ),
                                    ),
                                  ),
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      Padding(
                                        padding: const EdgeInsets.fromLTRB(10, 0, 5, 40),
                                        child: FittedBox(
                                          child: Container(
                                            width: 160,
                                            height: 110,
                                            child: Text('HELLO',
                                              overflow: TextOverflow.ellipsis,
                                              style: TextStyle(fontSize: 20,color: Colors.white),
                                              maxLines: 4,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(width: 115,),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
